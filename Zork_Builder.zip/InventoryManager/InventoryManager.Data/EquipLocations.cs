﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryManager.Data
{
    public enum EquipLocations
    {
        LeftHand,
        RightHand,
        Head,
        Feet
    }
}
